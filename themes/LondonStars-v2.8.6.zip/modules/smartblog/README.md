PrestaShop-Blog
===============

World Class Prestashop Blog, Developed By smartdatasoft



<h1>Version 2.1</h1>


<h2>Documentation </h2> url : http://smartdatasoft.com/doc/ps/smartblog/

Best Usage 

License

Smart Prestashop  Blog is released under GPLv3 - http://www.gnu.org/copyleft/gpl.html. You are free to redistribute & modify copies of the plugin under the following conditions:

All links & credits must be kept intact
For commercial usage (e.g in themes you're selling on any marketplace, or a commercial website), you are strongly recommended to link back to my Themeforest Profile Page using the following text: Smart Prestashop Blog by Smartdatasoft


<form target="_top" method="post" action="https://www.paypal.com/cgi-bin/webscr" sourceindex="0">
<input type="hidden" value="_s-xclick" name="cmd">
<input type="hidden" value="MZVKZ8NJLXV2W" name="hosted_button_id">
<input type="image" border="0" alt="PayPal - The safer, easier way to pay online!" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" sourceindex="1">
<img width="1" height="1" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" alt="">
</form>

<h1>Contacts</h1>

Twitter: http://twitter.com/smartdatasoft

Website: http://smartdatasoft.com

addons.prestashop.com  : http://addons.prestashop.com/en/69_smartdatasoft

ThemeForest : http://themeforest.net/user/smartdatasoft/portfolio

Codecanyon : codecanyon.net/user/smartdatasoft/portfolio
