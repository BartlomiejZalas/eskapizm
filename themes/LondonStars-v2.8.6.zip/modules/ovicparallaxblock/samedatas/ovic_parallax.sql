INSERT INTO PREFIX_ovic_parallax VALUES("1","83152d1d2f0e12193a7168a3760a7da4.jpg","0.1","blocktestimonial","HOOK_TESTIMONIAL","3","0","1");

