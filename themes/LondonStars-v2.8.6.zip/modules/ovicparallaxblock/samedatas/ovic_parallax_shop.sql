INSERT INTO PREFIX_ovic_parallax_shop VALUES("1","1");

