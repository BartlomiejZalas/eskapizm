INSERT INTO PREFIX_ovic_parallax_lang VALUES("1","id_lang","");

