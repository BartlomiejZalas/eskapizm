INSERT INTO PREFIX_simplecategory_group_lang VALUES("1","id_lang","Top rated","","");
INSERT INTO PREFIX_simplecategory_group_lang VALUES("2","id_lang","Sale Product","","");
