INSERT INTO PREFIX_simplecategory_module_lang VALUES("1","id_lang","home 5","","");
