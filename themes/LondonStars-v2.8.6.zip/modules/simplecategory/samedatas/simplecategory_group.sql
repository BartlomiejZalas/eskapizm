INSERT INTO PREFIX_simplecategory_group VALUES("1","1","category_id2","12","seller","desc","all","2","2","2","auto","1","1","","{\"color\":null,\"icon\":\"\",\"icon_active\":\"\"}","","");
INSERT INTO PREFIX_simplecategory_group VALUES("2","1","category_id2","12","date_add","desc","all","1","2","2","auto","2","1","","{\"color\":null,\"icon\":\"\",\"icon_active\":\"\"}","","");
