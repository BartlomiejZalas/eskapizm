<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{scrolltop}prestashop>footer_089b0cdd8835d09cb1cabf38b3ce9c09'] = 'scroll';
$_MODULE['<{scrolltop}prestashop>scrolltop_6d2fb53e17cf29ae7ff2552fa28d3289'] = 'Scroll to top';
$_MODULE['<{scrolltop}prestashop>scrolltop_426d5a31b80f8d3df89b3d8f276902eb'] = 'Button do przewijania okna strony na samą górę';
$_MODULE['<{scrolltop}prestashop>scrolltop_6761e135fa31a256983cc0de4ff8d7d9'] = 'Wersja kolorystyczna buttona';
$_MODULE['<{scrolltop}prestashop>scrolltop_a18366b217ebf811ad1886e4f4f865b2'] = 'Ciemna';
$_MODULE['<{scrolltop}prestashop>scrolltop_9914a0ce04a7b7b6a8e39bec55064b82'] = 'Jasna';
$_MODULE['<{scrolltop}prestashop>scrolltop_bad6a5dd8c28e6b14f8e986615e3dc98'] = 'Opacity';
$_MODULE['<{scrolltop}prestashop>scrolltop_c420b8cf0fa0acb5915773b2d2fd5499'] = 'ustaw pozycję';
$_MODULE['<{scrolltop}prestashop>scrolltop_43781db5c40ecc39fd718685594f0956'] = 'zapisz';
